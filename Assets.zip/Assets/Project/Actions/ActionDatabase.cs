using System.Collections.Generic;
using UnityEngine;
using static ActionDefinition;

public static class ActionDatabase
{
    public static Dictionary<string, ActionDefinition> Definitions =
        new Dictionary<string, ActionDefinition>()
        {
            {ActionIds.Attack, new ActionDefinition(
                ActionIds.Attack, TargetType.Enemy, true, 1, 1,
                cooldown: 0, dealsDamage: true,
                targetingMode: ActionDefinition.TargetingMode.Tile,
                category: ActionDefinition.ActionCategory.Standard,
                effects: new List<IActionEffect>
                {
                    new DamageEffect()
                }
            )},
            {ActionIds.FocusShot, new ActionDefinition(
                ActionIds.FocusShot, TargetType.Enemy, true, 2, 5,
                cooldown: 2, dealsDamage: true,
                targetingMode: ActionDefinition.TargetingMode.Tile,
                category: ActionDefinition.ActionCategory.Standard,
                effects: new List<IActionEffect>
                {
                    new ApplySelfStatusEffectEffect(unit => new FocusShotDamageEffect(10)),
                    new DamageEffect()
                }
            )},
            {ActionIds.Defend, new ActionDefinition(
                ActionIds.Defend, TargetType.None, false, 0, 0,
                cooldown: 0, dealsDamage: false,
                targetingMode: ActionDefinition.TargetingMode.None,
                category: ActionDefinition.ActionCategory.Standard,
                effects: new List<IActionEffect>
                {
                    new ApplyStatusEffectActionEffect(target =>
                        new DefenseBuffEffect(0.5f, 2))
                }
            )},
            {ActionIds.TacticalBoost, new ActionDefinition(
                ActionIds.TacticalBoost, TargetType.Ally, true, 0, 5,
                cooldown : 2, dealsDamage : false,
                targetingMode: ActionDefinition.TargetingMode.UI,
                category : ActionDefinition.ActionCategory.Standard,
                effects: new List<IActionEffect>
                {
                    new ApplyStatusEffectActionEffect(target =>
                        new NextAttackBonusEffect(5))
                }
            )},
            {ActionIds.Taunt, new ActionDefinition(
                ActionIds.Taunt, TargetType.Enemy, false, 0, 0,
                cooldown : 2, dealsDamage : false,
                targetingMode: ActionDefinition.TargetingMode.None,
                category : ActionDefinition.ActionCategory.Standard,
                effects: new List<IActionEffect>
                {
                    new ApplyStatusEffectToEnemiesEffect((source, target) =>
                        new TauntEffect(source, 2))
                }
            )},
            {ActionIds.Move, new ActionDefinition(
                ActionIds.Move, TargetType.None, false, 0, 0,
                cooldown: 0, dealsDamage: false,
                targetingMode: ActionDefinition.TargetingMode.Tile,
                category: ActionCategory.Move,
                effects: new List<IActionEffect>
                {
                    new MoveEffect()
                }
            )},
            {ActionIds.PowerStrike, new ActionDefinition(
                ActionIds.PowerStrike, TargetType.Enemy, true, 1, 1,
                cooldown: 2, dealsDamage: true,
                targetingMode: ActionDefinition.TargetingMode.Tile,
                category: ActionCategory.Standard,
                consumesCategories: new List<ActionCategory>
                {
                    ActionCategory.Move,
                    ActionCategory.Standard
                }
            )},
            {ActionIds.Pass, new ActionDefinition(
                ActionIds.Pass, TargetType.None, false, 0, 0,
                cooldown: 0, dealsDamage: false,
                targetingMode: ActionDefinition.TargetingMode.None,
                category: ActionDefinition.ActionCategory.Free,
                effects: new List<IActionEffect>()
            )},
        };
}
