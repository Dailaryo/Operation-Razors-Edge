using UnityEngine;

public static class ActionIds
{
    public const string Attack = "Attack";
    public const string Defend = "Defend";
    public const string Move = "Move";
    public const string FocusShot = "Focus Shot";
    public const string TacticalBoost = "Tactical Boost";
    public const string Taunt = "Taunt";
    public const string PowerStrike = "Power Strike";
    public const string Pass = "Pass";

}
