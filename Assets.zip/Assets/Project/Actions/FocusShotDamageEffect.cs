using UnityEngine;
using System.Collections.Generic;

public class FocusShotDamageEffect : StatusEffect
{
    private int bonus;

    public FocusShotDamageEffect(int bonus) : base("Focus Shot Bonus", 1)
    {
        this.bonus = bonus;
    }

    public override List<StatModifier> GetStatModifiers(Unit unit)
    {
        return new List<StatModifier>
        {
            new StatModifier(StatType.Attack, flat: bonus, 1f, source: effectName)
        };
    }
}