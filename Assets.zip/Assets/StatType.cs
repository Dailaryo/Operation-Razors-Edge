using UnityEngine;

public enum StatType
{
    Attack,
    MaxHP,
    Initiative
}
